<!--
Got a question?
===============
The issue list of this repo is exclusively for bug reports and feature requests. For questions, please use the following resources:

- Read the docs: https://github.com/pagekit/vue-resource/tree/master/docs
- Look for/ask questions on stack overflow: http://stackoverflow.com/search?q=vue-resource

Thank you!
-->

<!-- BUG REPORT TEMPLATE -->
### Reproduction Link
<!-- A minimal jsfiddle that can reproduce the bug. -->
<!-- You could start with this template: https://jsfiddle.net/pjjr7e7m/ -->

### Steps to reproduce
<!-- Incl. which version is used on what browser and device. -->

### What is Expected?

### What is actually happening?
